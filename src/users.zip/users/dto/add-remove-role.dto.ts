export class AddRemoveRoleDto {
  readonly userId: number;
  readonly role_value: string;
}
