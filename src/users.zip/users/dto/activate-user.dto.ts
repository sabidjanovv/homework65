export class ActivateUserDto {
  readonly userId: number;
}
